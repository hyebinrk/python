def save_attendance(self):
    QMessageBox.information(self, "디버깅", "✅ 버튼이 클릭되었습니다!")  # 클릭 여부 확인
    print("✅ 버튼 클릭됨!")  # 터미널에서도 확인
